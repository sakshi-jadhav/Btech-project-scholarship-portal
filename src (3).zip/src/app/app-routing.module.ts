import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { StudentLoginComponent } from './student/student-login/student-login.component';
import { StudentRegistrationComponent } from './student/student-registration/student-registration.component';
import { HomeComponent } from './home/home.component';
import { CompanyLoginComponent } from './company/company-login/company-login.component';
import { CompanyRegistrationComponent } from './company/company-registration/company-registration.component';
import { StudentCredComponent } from './student/Student-cred/student-cred/student-cred.component';
import { StepperComponent, passwordValidator } from 'src/stepper/stepper.component';
import { PasswordComponent } from 'src/password/password.component';
import { PasswordValidatorComponent } from 'src/password-validator/password-validator.component';
import { GridListComponent } from 'src/grid-list/grid-list.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'student-login', component: StudentLoginComponent },
  { path: 'student-register', component: StudentRegistrationComponent },
  { path: 'company-login', component: CompanyLoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'student-cred', component: StudentCredComponent },
  { path: 'student-cred2', component: StudentCredComponent },
  { path: 'stepper', component: StepperComponent },
  { path: 'password', component: PasswordComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'grid', component: GridListComponent },
  
  { path: 'company-registration', component: CompanyRegistrationComponent },
  { path: 'passwordvalidator', component: PasswordValidatorComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
