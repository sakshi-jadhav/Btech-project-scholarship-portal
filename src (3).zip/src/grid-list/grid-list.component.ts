import { Component, Injectable} from '@angular/core';
import {MatGridListModule} from '@angular/material/grid-list';

import {MatPaginatorIntl, MatPaginatorModule} from '@angular/material/paginator';
import {Subject} from 'rxjs';


@Injectable()
export class CustomPaginatorIntl {
  constructor(private paginator: MatPaginatorIntl) {
    this.paginator = this.getCustomPaginator();
  }

  getCustomPaginator(): MatPaginatorIntl {
    const customPaginator = new MatPaginatorIntl();

    customPaginator.firstPageLabel = 'First page';
    customPaginator.itemsPerPageLabel = 'Items per page:';
    customPaginator.lastPageLabel = 'Last page';
    customPaginator.nextPageLabel = 'Next page';
    customPaginator.previousPageLabel = 'Previous page';

    customPaginator.getRangeLabel = (page: number, pageSize: number, length: number): string => {
      if (length === 0 || pageSize === 0) {
        return `0 of ${length}`;
      }

      const startIndex = page * pageSize;
      const endIndex = Math.min(startIndex + pageSize, length);

      return `${startIndex + 1} - ${endIndex} of ${length}`;
    };

    return customPaginator;
  }
}
@Component({
  selector: 'app-grid-list',
  templateUrl: './grid-list.component.html',
  styleUrls: ['./grid-list.component.css'],
  providers: [{ provide: MatPaginatorIntl, useClass: CustomPaginatorIntl  }],
})
export class GridListComponent {

    cards = [
        {
            title: 'Notice Board',
            description: 'Important notices and announcements.'
            // Add more properties as needed
        },
        {
            title: 'Search Scholarship',
            description: 'Find scholarships for your education.'
            // Add more properties as needed
        },
        {
            title: 'Education Loan',
            description: 'Information about education loans.'
            // Add more properties as needed
        }
        // Add more cards as necessary
    ];
}