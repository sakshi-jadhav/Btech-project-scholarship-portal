import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  // formData = {
  //   username: '',
  //   password: ''
  // };

  // login() {
  //   // Implement your authentication logic here
  //   if (this.formData.username === 'yourUsername' && this.formData.password === 'yourPassword') {
  //     // Successful login
  //     alert('Login successful');
  //   } else {
  //     // Failed login
  //     alert('Login failed');
  //   }
  // }
}
