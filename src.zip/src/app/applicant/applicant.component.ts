import { Component } from '@angular/core';
import {MatTabsModule} from '@angular/material/tabs';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from '../app/app-routing.module';

@Component({
  selector: 'app-applicant',
  templateUrl: './applicant.component.html',
  styleUrls: ['./applicant.component.css']
})

export class ApplicantComponent {

}
