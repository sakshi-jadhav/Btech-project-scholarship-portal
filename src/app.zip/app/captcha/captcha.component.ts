// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-captcha',
//   templateUrl: './captcha.component.html',
//   styleUrls: ['./captcha.component.css']
// })
// export class CaptchaComponent {

// }

import { Component, AfterViewInit, ElementRef, ViewChild, Renderer2, OnInit } from '@angular/core';

@Component({
  selector: 'app-captcha',
  templateUrl: './captcha.component.html',
  styleUrls: ['./captcha.component.css']
})
export class CaptchaComponent  implements OnInit {
  captchaText: string = this.generateCaptchaText();
  userInput: string = '';
  validationMessage: string = '';

  generateCaptchaText(): string {
    // Generate a random CAPTCHA text (you can customize this logic)
    const possibleChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const captchaLength = 6;
    let captcha = '';
    for (let i = 0; i < captchaLength; i++) {
      const randomIndex = Math.floor(Math.random() * possibleChars.length);
      captcha += possibleChars[randomIndex];
    }
    return captcha;
  }

  checkCaptcha() {
    if (this.userInput === this.captchaText) {
      this.validationMessage = 'CAPTCHA is correct!';
    } else {
      this.validationMessage = 'CAPTCHA is incorrect. Please try again.';
    }
  }

  ngOnInit(): void {
  }
}